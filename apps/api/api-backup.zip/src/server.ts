import Fastify, { FastifyReply, FastifyRequest } from "fastify";
import cors        from "@fastify/cors";
import helmet      from "@fastify/helmet";
import jwt         from "@fastify/jwt";
import rateLimit   from "@fastify/rate-limit";
import multipart   from "@fastify/multipart";
import { nanoid }  from "nanoid";
import { ZodError } from "zod";

import { config }             from "./config.js";
import { getRoleFromRequest } from "./auth.js";

import listingRoutes  from "./routes/listings.js";
import scoringRoutes  from "./routes/scoring.js";
import watchlistRoutes from "./routes/watchlist.js";
import healthRoutes   from "./routes/health.js";
import paymentRoutes  from "./routes/payments.js";
import authRoutes     from "./routes/auth.js";
import adminRoutes    from "./routes/admin.js";
import intelligenceRoutes from "./routes/intelligence.js";
import sellerRoutes   from "./routes/seller.js";
import { dealRoutes } from "./routes/deal.js";

declare module "fastify" {
  interface FastifyRequest  { requestId: string; }
  interface FastifyInstance { authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>; }
}

export const buildServer = () => {
  const app = Fastify({ logger: true });

  if (config.demoMode) {
    app.log.warn("DEMO_MODE enabled — serving seeded inventory");
  }

  app.decorateRequest("requestId", "");

  // CORS
  app.register(cors, {
    origin: (origin, cb) => {
      if (!origin) return cb(null, true);
      if (config.corsOrigins.includes(origin)) return cb(null, true);
      return cb(new Error("Origin not allowed"), false);
    },
    credentials: true,
  });

  // Security headers
  app.register(helmet);

  // JWT
  app.register(jwt, { secret: config.jwtSecret });

  // Auth decorator
  app.decorate("authenticate", async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      await request.jwtVerify();
    } catch {
      return reply.status(401).send({
        error: { code: "UNAUTHORIZED", message: "Authentication required.", requestId: request.requestId },
      });
    }
  });

  // Rate limiting — tiered by role
  app.register(rateLimit, {
    timeWindow: "1 minute",
    max: (request: FastifyRequest) => {
      const role = getRoleFromRequest(request as any);
      if (role === "admin")  return 600;
      if (role === "seller") return 240;
      if (role === "buyer")  return 120;
      return 30;
    },
  });

  // File uploads — 5MB cap
  app.register(multipart, { limits: { fileSize: 5 * 1024 * 1024 } });

  // Request ID + optional auth on every request
  app.addHook("onRequest", async (request, reply) => {
    const requestId = nanoid();
    request.requestId = requestId;
    reply.header("x-request-id", requestId);

    const authHeader = request.headers.authorization;
    if (authHeader?.startsWith("Bearer ")) {
      try { await request.jwtVerify(); } catch { /* optional, ignore */ }
    }
  });

  // Central error handler
  app.setErrorHandler((error: any, request, reply) => {
    request.log.error(error);
    const isZod    = error instanceof ZodError;
    const status   = error.statusCode ?? (isZod ? 400 : 500);
    const code     = isZod ? "BAD_REQUEST" : (error.code ?? "SERVER_ERROR");
    const message  = isZod ? "Invalid request." : (error.message ?? "Unexpected error");
    reply.status(status).send({ error: { code, message }, requestId: request.requestId });
  });

  // Routes
  app.register(healthRoutes,   { prefix: "/api" });
  app.register(authRoutes,     { prefix: "/api/auth" });
  app.register(listingRoutes,  { prefix: "/api/listings" });
  app.register(scoringRoutes,  { prefix: "/api/scoring-configs" });
  app.register(watchlistRoutes,{ prefix: "/api/watchlist" });
  app.register(paymentRoutes,  { prefix: "/api/payments" });
  app.register(adminRoutes,    { prefix: "/api/admin" });
  app.register(intelligenceRoutes, { prefix: "/api/intelligence" });
  app.register(sellerRoutes,   { prefix: "/api/seller" });
  app.register(dealRoutes,     { prefix: "/api" });

  return app;
};
